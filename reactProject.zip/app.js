const express = require('express');
const path = require('path');
var mysql = require('mysql');
var bodyParser = require('body-parser');
var cookieParser = require('cookie-parser');
var cors = require('cors');
const port =  3000
const app = express()
var AWS = require('aws-sdk');
var s3Router = require('react-s3-uploader/s3router');
var Login = require('./routes/login');


app.use(function (req, res, next) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT ,DELETE');
  res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type, Authorization');
  next();
});

app.use(cors());
app.use(bodyParser.json({limit: '50mb'}));
app.use(bodyParser.urlencoded({limit: '50mb', extended: true}));

app.use(cookieParser());
app.use('/', express.static(__dirname + "/public"));




app.use('/login', Login);


app.get('*', function (request, response){
  response.sendFile(path.resolve(__dirname, 'public', 'index.html'))
})


// AWS
// .config
// .update({accessKeyId: 'AKIAIMXKBYNNECJSXSSA', secretAccessKey: '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'});

// app.use('/s3', s3Router({
// bucket: 'toolkittesting',
// ACL: 'public-read',
// headers: {
//   'Access-Control-Allow-Origin': '*'
// },
// uniquePrefix: false
// }));



app.use(function (req, res, next) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT ,DELETE');
    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type, Authorization');
    next();
  });

  AWS.config.update({
    accessKeyId:  'AKIAJ2K6GVKGGNUAJDEA',
    secretAccessKey:  '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'
  });
  
  
  app.use('/s3', s3Router({
    bucket: 'reactproject',
    ACL: 'public-read',
    headers: { 'Access-Control-Allow-Origin': '*' },
    uniquePrefix: false
  }));
 
app.listen(port)
console.log("server started on port " + port)
