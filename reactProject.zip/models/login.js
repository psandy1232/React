var db = require('../dbconnection');
var _ = require('lodash');
var googl = require('goo.gl')
var login = {
    authCheck: function (userName,callback) {
        console.log('gdfgdf')
        googl.setKey('AIzaSyCRFDyIte6n9hGC3BfwBh6WB71iKH8h1DQ');
        
        // Get currently set developer key 
       googl.getKey();
        
       // Shorten a long url and output the result 
       googl.shorten('http://prodheeraj.com/testing')
           .then(function (shortUrl) {
               console.log(shortUrl);
           })
           .catch(function (err) {
               console.error(err.message);
           });
        return db.query("select * from cities", callback);
    },
    

       };

module.exports = login;
