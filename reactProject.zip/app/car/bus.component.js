import React, { Component } from 'react';

// class Bus extends Component {
//
//
//     render(){
//
//         return (<h1>Bus</h1>);
//     }
// }


const Bus = (props) => {

  return <p>{props.x.firstname}{props.x.key}</p>
}

export default Bus
