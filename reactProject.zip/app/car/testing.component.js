'use strict'

import React, {Component, PropTypes} from 'react'
import QrReader from 'react-qr-reader'
import S3Upload from 'react-s3-uploader/s3upload';


class Testing extends Component{
constructor(props){
  super(props)
  this.state={
    data:'sid',
    data1:[],
    delay: 300,
    result: 'No result',
  }
}

handleScan(data){
  if(data){
    this.setState({
      result: data,
    })
  }
}
handleError(err){
  console.error(err)
}

  update(e){
    this.setState({data:e.target.value})
  }


  remove(){
  var arr = this.state.data1;
  var arrr = arr.splice(0,1);
  this.setState({data1:arrr})
  }

  async _handleImageChange(e) {
    e.preventDefault();
   
    let reader = new FileReader();
    let file = e.target.files[0];
 
    //const fileIndex = e.target.name.split('-');
    const S3Uploader = new S3Upload({
      files: [file],
      signingUrl: '/s3/sign',
      signingUrlQueryParams: {},
      s3path:  'siddu/',
      onProgress: this.onProgress.bind(this, file),
      onFinishS3Put: this.onFinish.bind(this, file),
      onError: this.onError.bind(this, file),
      uploadRequestHeaders: {'x-amz-acl': 'public-read'},
      contentDisposition: file.type,
      server: ''
    });
    console.log('ff--',S3Uploader)
  }
  
  async onProgress(file,progress){
    console.log('file---',progress)
  }

  async onFinish(info) {
    console.log('onFinish---',info)
  }

  onError(file, err) {
    console.log('rrr',err)
      }

render(){

return(
  <div>
  

</div>);

}


}

export default Testing
