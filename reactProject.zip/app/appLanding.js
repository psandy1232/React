import React, { Component } from 'react';
import ReactDOM from 'react-dom';


import routes from './routes';


ReactDOM.render(<div>{routes}</div>,document.getElementById('container')
);