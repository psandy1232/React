'use strict'

import serviceBase from './serviceBase'

const loginService = {

  /**
   * Gets current user
   * @returns {*}
   */
  authCheck:  (credentials) =>  serviceBase.post('/login',credentials),
  

}
export default loginService
